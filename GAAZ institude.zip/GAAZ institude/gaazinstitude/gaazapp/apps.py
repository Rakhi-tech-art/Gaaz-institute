from django.apps import AppConfig


class GaazappConfig(AppConfig):
    name = 'gaazapp'
