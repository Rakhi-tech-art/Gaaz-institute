from django.contrib import admin
from .models import Course

@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ("title", "duration", "badge", "order", "is_active")
    list_editable = ("order", "is_active")
    
from .models import Course, PlacementPartner

@admin.register(PlacementPartner)
class PlacementPartnerAdmin(admin.ModelAdmin):
    list_display = ("name", "order", "is_active")
    list_editable = ("order", "is_active")

from .models import Course, PlacementPartner, Instructor

@admin.register(Instructor)
class InstructorAdmin(admin.ModelAdmin):
    list_display = ("name", "order", "is_active")
    list_editable = ("order", "is_active")