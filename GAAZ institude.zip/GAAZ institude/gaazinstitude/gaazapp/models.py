from django.db import models

class Course(models.Model):
    BADGE_CHOICES = [
        ("Trending", "Trending"),
        ("Emerging Tech", "Emerging Tech"),
        ("Popular", "Popular"),
        ("New", "New"),
    ]
    title = models.CharField(max_length=150)
    description = models.CharField(max_length=255)
    image = models.ImageField(upload_to="courses/", blank=True, null=True)
    badge = models.CharField(max_length=30, choices=BADGE_CHOICES, blank=True)
    duration = models.CharField(max_length=50, default="6 Months")
    highlight = models.CharField(max_length=80, default="20+ Case Studies")
    detail_url = models.CharField(max_length=200, blank=True, default="#")
    order = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["order", "id"]

    def __str__(self):
        return self.title
    
class PlacementPartner(models.Model):
    name = models.CharField(max_length=100)
    logo = models.ImageField(upload_to="partners/", blank=True, null=True)
    order = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["order", "id"]

    def __str__(self):
        return self.name
    
class Instructor(models.Model):
    name = models.CharField(max_length=100)
    headline = models.CharField(max_length=255, help_text="Expertise and qualification line")
    bio = models.TextField()
    photo = models.ImageField(upload_to="instructors/", blank=True, null=True)
    stat1_value = models.CharField(max_length=20, default="5000+")
    stat1_label = models.CharField(max_length=40, default="Students trained")
    stat2_value = models.CharField(max_length=20, default="10+")
    stat2_label = models.CharField(max_length=40, default="years experience")
    linkedin_url = models.URLField(blank=True)
    order = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["order", "id"]

    def __str__(self):
        return self.name