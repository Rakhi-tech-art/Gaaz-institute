from django.shortcuts import render
from .models import Course

def home(request):
    courses = Course.objects.filter(is_active=True)
    return render(request, "index.html", {"courses": courses})

from .models import Course, PlacementPartner

def home(request):
    return render(request, "index.html", {
        "courses": Course.objects.filter(is_active=True),
        "partners": PlacementPartner.objects.filter(is_active=True),
    })

from .models import Course, PlacementPartner, Instructor

def home(request):
    return render(request, "index.html", {
        "courses": Course.objects.filter(is_active=True),
        "partners": PlacementPartner.objects.filter(is_active=True),
        "instructors": Instructor.objects.filter(is_active=True),
    })